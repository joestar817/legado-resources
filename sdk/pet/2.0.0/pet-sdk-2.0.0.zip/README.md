# 阅读 NG 宠物 SDK 2.0.0

一个作者工程包含一份 pet.json、Kotlin 或 Java 源码，以及可选的原始素材。构建工具会由 pet.json 生成包内的 assets/plugin.json，检查编译后的入口，输出可以直接上架的单层 ZIP。

## 获取 SDK 和创建项目

在阅读工程中用 Windows PowerShell 生成 SDK。发布给作者的是 build/outputs/pet-sdk/pet-sdk-2.0.0.zip，内含固定接口 JAR、打包工具、Gradle wrapper 和光球模板。阅读 App 的构建仅依赖基础接口模块。

    $env:GRADLE_USER_HOME = 'D:\code\.gradle-legado'
    .\gradlew.bat :modules:pet-api:exportPetSdk --no-parallel

以下步骤在作者机器上执行。安装 JDK 17 和带 android-36 平台的 Android SDK，将 ANDROID_HOME 指向其目录。把 SDK 解压到工具目录，将 template 复制为独立的插件工程。

    Expand-Archive -LiteralPath .\pet-sdk-2.0.0.zip -DestinationPath .\pet-sdk
    Copy-Item -LiteralPath .\pet-sdk\template -Destination .\my-orb -Recurse
    $builder = (Resolve-Path .\pet-sdk).Path
    $pet = (Resolve-Path .\my-orb).Path
    & "$builder\gradlew.bat" -p $builder "-PpetProject=$pet" packagePet --no-parallel

产物位于 my-orb/build/outputs/pet/orb-1.zip。构建在插件工程自己的 build 目录写入临时文件与产物。插件工程可以放在任意目录，不需要阅读 App 源码。Unix 下使用同一 SDK 中的 gradlew。

## 插件配置和接口

| 字段 | 约定 |
| --- | --- |
| id | 同一插件的稳定身份。小写字母开头，随后可用小写字母、数字和下划线，总长不超过 64。none 与 button 为保留值 |
| name | 安装后显示的名称 |
| versionCode | 每次发布新包递增的整数，须与目录版本一致 |
| entryClass | 实现 io.legado.pet.api.PetPlugin 的公开类的 JVM 二进制名称，例如 example.OrbPlugin 或 example.Factory$Orb。入口提供公开无参构造函数，其 id 与清单相同 |
| sharedSources | 可选的作者共享源码相对目录，由这些源码编译出的角色逻辑归插件所有 |

SDK 工具固定输出 schemaVersion=2、kind=pet、apiVersion=2。包内携带插件自己的 Kotlin 运行依赖。发布校验检查入口实现、主应用内部类型引用和重复打入的 SDK 类。插件可按照需要在 src/main/assets/ 下放置文件，素材保留作者提供的字节。

PetPlugin.createSession 在后台准备资源。宿主将当前会话移交给界面线程后，以视口 dp 派发绘制和输入。会话自行绘制、计算命中并决定下帧时间，release 返回 true 表达激活意图，聊天导航归宿主负责。宿主隐藏窗口时暂停驱动并通知 setVisible，切换后调用 close 释放资源。saveState 可返回最多 4096 字节的角色私有数据，自行维护数据版本并处理空数据或不支持的版本。

## 验证独立更新

模板的第一版使用 Canvas 绘制光球，支持拖动、点击及位置恢复。验证第二版时，在复制出的作者工程中应用 SDK 内的 examples/orb-v2.patch，再次执行相同的 packagePet 命令。补丁同时修改实际动作和发布版本，生成 orb-2.zip，拖动释放后产生逐渐消退的光晕。两版使用相同的插件 ID 和状态格式。该示例供开发和验收使用。

    Push-Location $pet
    git apply "$builder\examples\orb-v2.patch"
    Pop-Location
    & "$builder\gradlew.bat" -p $builder "-PpetProject=$pet" packagePet --no-parallel

## 两只已有宠物

本仓库的 pet-gugugaga、pet-blue-fish 都是独立作者工程，共用的旧角色绘制与动画工具位于 pet-layered/src/main/java。以这两个工程各自的绝对目录作为 petProject，就能使用与模板相同的 SDK 命令构建 gugugaga-2.zip 与 blue_fish-2.zip。

资源中心按 pet 类型、包内身份、摘要和接口版本校验这些 ZIP。下载入库后由用户显式启用。插件与宿主同进程运行，官方资源仓库负责可信代码分发。
